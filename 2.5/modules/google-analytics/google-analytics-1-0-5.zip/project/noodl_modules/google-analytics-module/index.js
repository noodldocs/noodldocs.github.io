/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@noodl/noodl-sdk/index.js":
/*!************************************************!*\
  !*** ./node_modules/@noodl/noodl-sdk/index.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

const _colors = {
    "purple":"component",
    "green":"data",
    "default":"default",
    "grey":"default"
}

Noodl.defineNode = function(def) {
    const _def = {};

    _def.name = def.name;
    _def.displayNodeName = def.displayName;
    _def.usePortAsLabel = def.useInputAsLabel;
    _def.color = _colors[def.color || 'default'];
    _def.category = def.category || 'Modules';
    _def.getInspectInfo = def.getInspectInfo;
    _def.docs = def.docs;
    
    _def.initialize = function() {
        this.inputs = {};
        var _outputs = this.outputs = {};
        var _this = this;

        // Function for quickly setting outputs
        this.setOutputs = function(o) {
            for(var key in o) {
                _outputs[key] = o[key];
                _this.flagOutputDirty(key);
            }
        }

        // Sending warnings
        this.clearWarnings = (function() {
            if(this.context.editorConnection && this.nodeScope && this.nodeScope.componentOwner)
                this.context.editorConnection.clearWarnings(this.nodeScope.componentOwner.name, this.id);
        }).bind(this);

        this.sendWarning = (function(name,message) {
            if(this.context.editorConnection && this.nodeScope && this.nodeScope.componentOwner)
                this.context.editorConnection.sendWarning(this.nodeScope.componentOwner.name, this.id, name, {
                    message: message
                });
        }).bind(this);

        if(typeof def.initialize === 'function')
            def.initialize.apply(this);
    }
    _def.inputs = {};
    _def.outputs = {};

    for(var key in def.inputs) {
        _def.inputs[key] = {
            type:(typeof def.inputs[key] === 'object')?def.inputs[key].type:def.inputs[key],
            displayName:(typeof def.inputs[key] === 'object')?def.inputs[key].displayName:undefined,
            group:(typeof def.inputs[key] === 'object')?def.inputs[key].group:undefined,
            default:(typeof def.inputs[key] === 'object')?def.inputs[key].default:undefined,
            set:(function() { const _key = key; return function(value) {
                this.inputs[_key] = value;
                if(def.changed && typeof def.changed[_key] === 'function') {
                    def.changed[_key].apply(this,[value]);
                }
            }})()
        }
    }

    for(var key in def.signals) {
        _def.inputs[key] = {
            type:'signal',
            displayName:(typeof def.signals[key] === 'object')?def.signals[key].displayName:undefined,
            group:(typeof def.signals[key] === 'object')?def.signals[key].group:undefined,
            valueChangedToTrue:(function() { const _key = key; return function() {
                const _fn = (typeof def.signals[_key] === 'object')?def.signals[_key].signal:def.signals[_key]
                if(typeof _fn === 'function') {
                    this.scheduleAfterInputsHaveUpdated(() => {
                        _fn.apply(this);
                    }) 
                }
            }})()
        }
    }

    for(var key in def.outputs) {
        if(def.outputs[key] === 'signal') {
            _def.outputs[key] = {
                type:'signal',
            }
        }
        else {
            _def.outputs[key] = {
                type:(typeof def.outputs[key] === 'object')?def.outputs[key].type:def.outputs[key],
                displayName:(typeof def.outputs[key] === 'object')?def.outputs[key].displayName:undefined,
                group:(typeof def.outputs[key] === 'object')?def.outputs[key].group:undefined,
                getter:(function() { const _key = key; return function() {
                    return this.outputs[_key];
                }})()
            }
        }
    }

    _def.methods = _def.prototypeExtensions = {};
    for(var key in def.methods) {
        _def.prototypeExtensions[key] = def.methods[key];
    }
    if(_def.methods.onNodeDeleted) { // Override the onNodeDeleted if required
        _def.methods._onNodeDeleted = function() {
            this.__proto__.__proto__._onNodeDeleted.call(this);
            _def.methods.onNodeDeleted.value.call(this);
        }
    }

    return {node:_def,setup:def.setup};
}

Noodl.defineCollectionNode = function(def) {
    const _def = {
        name:def.name,
        category:def.category,
        color:'data',
        inputs:def.inputs,
        outputs:Object.assign({
            Items:'array',
            'Fetch Started':'signal',
            'Fetch Completed':'signal'
        },def.outputs||{}),
        signals:Object.assign({
            Fetch:function() {
                var _this = this;
                this.sendSignalOnOutput('Fetch Started');
                var a = def.fetch.call(this,function() {
                    _this.sendSignalOnOutput('Fetch Completed');
                });
                this.setOutputs({
                    Items:a
                })
            }
        },def.signals||{})
    }

    return Noodl.defineNode(_def);
}

Noodl.defineModelNode = function(def) {
    const _def = {
        name:def.name,
        category:def.category,
        color:'data',
        inputs:{
            Id:'string'
        },
        outputs:{
            Fetched:'signal'
        },
        changed:{
            Id:function(value) {
                if(this._object && this._changeListener)
                    this._object.off('change',this._changeListener)
                
                this._object = Noodl.Object.get(value);
                this._changeListener = (name,value) => {
                    const _o = {}
                    _o[name] = value;
                    this.setOutputs(_o)
                }
                this._object.on('change',this._changeListener)

                this.setOutputs(this._object.data);
                this.sendSignalOnOutput('Fetched');
            }
        },
        initialize:function() {

        }
    }

    for(var key in def.properties) {
        _def.inputs[key] = def.properties[key];
        _def.outputs[key] = def.properties[key];
        _def.changed[key] = (function() { const _key = key; return function(value) {
            if(!this._object) return;
            this._object.set(_key,value);
        }})()
    }
 
    return Noodl.defineNode(_def);
}

Noodl.defineReactNode = function(def) {
    var _def = Noodl.defineNode(def);

    _def.node.getReactComponent = def.getReactComponent;
    _def.node.inputProps = def.inputProps;
    _def.node.inputCss = def.inputCss;
    _def.node.outputProps = def.outputProps;
    _def.node.setup = def.setup;
    _def.node.frame = def.frame;

    return _def.node;
}

module.exports = Noodl;

/***/ }),

/***/ "./src/constants.ts":
/*!**************************!*\
  !*** ./src/constants.ts ***!
  \**************************/
/*! exports provided: MODULE_NAMESPACE */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MODULE_NAMESPACE", function() { return MODULE_NAMESPACE; });
var MODULE_NAMESPACE = 'noodl.googleAnalyticsModule';


/***/ }),

/***/ "./src/index.ts":
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @noodl/noodl-sdk */ "./node_modules/@noodl/noodl-sdk/index.js");
/* harmony import */ var _noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nodes_GoogleAnalyticsInitializer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nodes/GoogleAnalyticsInitializer */ "./src/nodes/GoogleAnalyticsInitializer.tsx");
/* harmony import */ var _nodes_SendAnalyticsData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./nodes/SendAnalyticsData */ "./src/nodes/SendAnalyticsData.ts");



_noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0__["defineModule"]({
    reactNodes: [_nodes_GoogleAnalyticsInitializer__WEBPACK_IMPORTED_MODULE_1__["GoogleAnalyticsInitializer"]],
    nodes: [_nodes_SendAnalyticsData__WEBPACK_IMPORTED_MODULE_2__["SendAnalyticsData"]],
});


/***/ }),

/***/ "./src/nodes/GoogleAnalyticsInitializer.tsx":
/*!**************************************************!*\
  !*** ./src/nodes/GoogleAnalyticsInitializer.tsx ***!
  \**************************************************/
/*! exports provided: GoogleAnalyticsInitializer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoogleAnalyticsInitializer", function() { return GoogleAnalyticsInitializer; });
/* harmony import */ var _noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @noodl/noodl-sdk */ "./node_modules/@noodl/noodl-sdk/index.js");
/* harmony import */ var _noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");



var NODE_NAME = "".concat(_constants__WEBPACK_IMPORTED_MODULE_2__["MODULE_NAMESPACE"], ".analyticsLoader");
function InitializerComponent(_a) {
    var measurementId = _a.measurementId, allowTracking = _a.allowTracking;
    Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
        if (measurementId && allowTracking) {
            var script = document.createElement('script');
            script.src = "https://www.googletagmanager.com/gtag/js?id=".concat(measurementId);
            document.head.appendChild(script);
            window.dataLayer = window.dataLayer || [];
            window.gtag = function () {
                window.dataLayer.push(arguments);
            };
            gtag('js', new Date());
            gtag('config', measurementId);
        }
    }, [measurementId, allowTracking]);
    return null;
}
var GoogleAnalyticsInitializer = _noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0__["defineReactNode"]({
    name: NODE_NAME,
    displayName: 'Google Analytics Root',
    docs: 'https://docs.noodl.net/#/modules/google-analytics/nodes/google-analytics-root/README.md',
    category: 'visual',
    getReactComponent: function () {
        return InitializerComponent;
    },
    inputs: {
        measurementId: {
            displayName: 'Measurement ID',
            type: 'string',
            default: undefined,
            group: 'Analytics',
        },
        allowTracking: {
            displayName: 'Allow Tracking',
            type: 'boolean',
            default: false,
            group: 'Analytics',
        },
    },
    methods: {
        _updateTrackingSignalIfAllowed: function () {
            if (this.props.allowTracking && this.props.measurementId) {
                this.sendSignalOnOutput('trackingStarted');
            }
        },
    },
    changed: {
        allowTracking: function (val) {
            this.props.allowTracking = val;
            this._updateTrackingSignalIfAllowed();
            this.forceUpdate();
        },
        measurementId: function (val) {
            this.props.measurementId = val;
            this._updateTrackingSignalIfAllowed();
            this.forceUpdate();
        },
    },
    outputProps: {
        trackingStarted: {
            type: 'signal',
            displayName: 'Starting Tracking',
            group: 'Analytics',
        },
    },
    // @ts-ignore
    mountedInput: false,
});


/***/ }),

/***/ "./src/nodes/SendAnalyticsData.ts":
/*!****************************************!*\
  !*** ./src/nodes/SendAnalyticsData.ts ***!
  \****************************************/
/*! exports provided: SendAnalyticsData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SendAnalyticsData", function() { return SendAnalyticsData; });
/* harmony import */ var _noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @noodl/noodl-sdk */ "./node_modules/@noodl/noodl-sdk/index.js");
/* harmony import */ var _noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants.ts");


var SendAnalyticsData = _noodl_noodl_sdk__WEBPACK_IMPORTED_MODULE_0__["defineNode"]({
    name: "".concat(_constants__WEBPACK_IMPORTED_MODULE_1__["MODULE_NAMESPACE"], ".sendAnalyticsData"),
    displayName: 'Send Google Analytics Data',
    docs: 'https://docs.noodl.net/#/modules/google-analytics/nodes/send-google-analytics-data/README.md',
    signals: {
        Do: function () {
            if (typeof window.gtag === 'undefined') {
                console.warn('Noodl Google Analytics Module: Tracking script not loaded. This might be because of a user opt-out.');
                return null;
            }
            var args;
            try {
                args = JSON.parse('[' + this.inputs.TrackingCode + ']');
            }
            catch (_a) {
                args = (0, eval)('([' + this.inputs.TrackingCode + '])');
            }
            window.gtag.apply(window, args);
            this.sendSignalOnOutput('DataSent');
        },
    },
    inputs: {
        TrackingCode: {
            displayName: 'Gtag Tracking Data',
            type: { name: 'string', codeeditor: 'javascript' },
            default: '"event", "search", {"term": "Udon"}',
            group: 'Analytics',
        },
    },
    outputs: {
        DataSent: {
            type: 'signal',
            displayName: 'Data Sent',
            group: 'Analytics',
        },
    },
});


/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = React;

/***/ })

/******/ });
//# sourceMappingURL=index.js.map